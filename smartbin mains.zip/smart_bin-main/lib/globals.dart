// TODO Implement this library.
// globals.dart
library my_app.globals;

String loggedInUsername = "";
